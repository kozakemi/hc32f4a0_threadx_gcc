# 感谢以下网友对本软件的关注

- zhangoneone：ESC按键问题，nr_micro_shell不支持某些特殊按键，仅支持常用字符按键。
- bean：应用代码至[BabyOS](https://gitee.com/notrynohigh/BabyOS)，并给予若干意见。
- pzibang：代码规范问题。
- fish : `queue->rp = queue->rp++;`IAR优化出错问题；IAR中提示重复声明问题；
- caochunchen : readme 中package位置说明错误