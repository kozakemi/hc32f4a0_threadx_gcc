# Azure RTOS IoT SDK API

###  [Azure IoT](./azure_rtos_iot.md)    
###  [Azure IoT Hub Client](./azure_rtos_iot_hub_client.md)
###  [Azure IoT Hub Client Properties](./azure_rtos_iot_hub_client_properties.md)
###  [Azure IoT Provisioning Client](./azure_rtos_iot_provisioning_client.md)
###  [Azure IoT JSON](./azure_rtos_iot_json.md)