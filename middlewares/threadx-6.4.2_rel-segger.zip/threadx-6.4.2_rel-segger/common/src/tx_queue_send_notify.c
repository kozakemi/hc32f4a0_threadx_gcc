/***************************************************************************
 * Copyright (c) 2024 Microsoft Corporation 
 * 
 * This program and the accompanying materials are made available under the
 * terms of the MIT License which is available at
 * https://opensource.org/licenses/MIT.
 * 
 * SPDX-License-Identifier: MIT
 **************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** ThreadX Component                                                     */
/**                                                                       */
/**   Queue                                                               */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define TX_SOURCE_CODE


/* Include necessary system files.  */

#include "tx_api.h"
#include "tx_trace.h"
#include "tx_queue.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _tx_queue_send_notify                               PORTABLE C      */
/*                                                           6.1          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Microsoft Corporation                             */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function registers an application callback function that is    */
/*    called whenever a messages is sent to this queue.                   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    queue_ptr                             Pointer to queue control block*/
/*    queue_send_notify                     Application callback function */
/*                                            (TX_NULL disables notify)   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  05-19-2020     William E. Lamie         Initial Version 6.0           */
/*  09-30-2020     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 6.1    */
/*                                                                        */
/**************************************************************************/
UINT  _tx_queue_send_notify(TX_QUEUE *queue_ptr, VOID (*queue_send_notify)(TX_QUEUE *notify_queue_ptr))
{

    TRACE_RECORD_U32(TRACE_API_TX_QUEUE_NOTIFY, TX_POINTER_TO_ULONG_CONVERT(queue_ptr));

#ifdef TX_DISABLE_NOTIFY_CALLBACKS

    TX_QUEUE_NOT_USED(queue_ptr);
    TX_QUEUE_SEND_NOTIFY_NOT_USED(queue_send_notify);

    TRACE_RECORD_END_CALL_U32(TRACE_API_TX_QUEUE_NOTIFY, TX_FEATURE_NOT_ENABLED);

    /* Feature is not enabled, return error.  */
    return(TX_FEATURE_NOT_ENABLED);
#else

TX_INTERRUPT_SAVE_AREA


    /* Disable interrupts.  */
    TX_DISABLE

    /* Make entry in event log.  */
    TX_TRACE_IN_LINE_INSERT(TX_TRACE_QUEUE_SEND_NOTIFY, queue_ptr, 0, 0, 0, TX_TRACE_QUEUE_EVENTS)

    /* Make entry in event log.  */
    TX_EL_QUEUE_SEND_NOTIFY_INSERT

    /* Setup queue send notification callback function.  */
    queue_ptr -> tx_queue_send_notify =  queue_send_notify;

    /* Restore interrupts.  */
    TX_RESTORE

    TRACE_RECORD_END_CALL_U32(TRACE_API_TX_QUEUE_NOTIFY, TX_SUCCESS);

    /* Return success to caller.  */
    return(TX_SUCCESS);
#endif
}

